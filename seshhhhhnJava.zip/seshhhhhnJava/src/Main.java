import java.security.spec.RSAOtherPrimeInfo;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

//import static com.sun.tools.javac.tree.TreeInfo.args;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        /*int [] array={1,2,3,4,9,6,4,8};
        //System.out.println(Arrays.toString(array));
        int max=array[0];
        for (int i=0;i< array.length-1;i++){
            if (array[i]>max)
                max=array[i];
            System.out.print(max);
        }

         */
       /* int [] array={1,2,3,4,9,6,4,8};
        System.out.println(Arrays.toString(array));
        int sum=0;
        for (int i = 0;i<array.length-1;i++){
            sum+=array[i];
        }
        float average=(float) sum/array.length;
        System.out.println(average);

        */
        /*int [] array={1,2,3,4,9,6,4,8};
        System.out.println(Arrays.toString(array));
        int sum=0;
        for (int i = 0;i<array.length-1;i++){
            if (i%2==0){

            }
        }
        System.out.println(sum);

         */
        /*int [] array={1,2,3,4,9,6,4,8};
        System.out.println(Arrays.toString(array));
        int sum=1;
        for (int i = 0;i<array.length-1;i++){
            sum*=array[i];
        }
        System.out.println(sum);

         */
        /*Scanner scanner = new Scanner(System.in);

       String[]array=new String[20];
        for (int i = 0;i<array.length;i++){
            System.out.println("Ввыедите имя ученика под индексом"+" "+i);
            array[i]=scanner.nextLine();

        }
        System.out.println(Arrays.toString(array));
        int choice= scanner.nextInt();


        System.out.println("Ьага бир индексти бер.ошол индекстин ичиндеги адамды чыгарып берем");
        for (int i = 0;i<array.length;i++){
            if (choice==i){
                System.out.println(array[i]);
                break;
            }else{
                System.out.println("net takogo");
            }
        }

         */
        /*int [] array={1,2,3,4,9,6,4,8};
        int [] neeeeeeeeeeew=new int[array.length-1];
        for (int i=0;i<array.length;i++){
            for (int j=i+1;j<array.length;j++){
                if(array[i]==)
            }
        }

         */
       /* int [] array={1,2,3,4,9,6,4,8,9,10,11,12,13,14,15};
         int count=0;
        for (int i = 1;i<array.length-1;i++){
            if (array[i]%2==0){
                count++;
            }

        }
        System.out.println(count);

        */
        /*int[] array = new int[50];
        int palo=0;
        for (int i = 1;n=1<;i++){

         */
        //fibonachhi
        /*int n0=1;
        int n1=1;     //fibonachhi
        int n2;
        System.out.println(n0+" "+n1+" ");
        for ( int i=1;i<10;i++){
            n2=n0+n1;
            System.out.println(n2+" ");
            n0=n1;
            n1=n2;
        }
        System.out.println();

         */
        /*int i ;
        int summa;
        summa=0;
        for(i=1;i<=1000;i=i+1){

            summa=summa+i;

        }
        System.out.println(summa);
        //cout <<summa<< endl;
        //System.out.println("pause");

         */


 /*sasa drrr =new sasa();
drrr.model ="mas";
drrr.color="grey";
drrr.price=1500;
drrr.ram=16;
        System.out.println(drrr.model);

        sasa drrr2 =new sasa();
        drrr2.model="lenovo";
        System.out.println(drrr2.model);

  */
        //model telefonov
     /*   System.out.println(" first model");
        Telephone name=new Telephone();
        name.model="iphone";
        name.year=2023;
        name.color="purple";
        name.cost=120000;
        System.out.println("Model :"+name.model);
        System.out.println("year  :"+name.year);
        System.out.println("color :"+name.color);
        System.out.println("cost  :"+name.cost);

        System.out.println();
        System.out.println(" second model");
        Telephone name1=new Telephone();
        name.model="Redmi";
        name.year=2016;
        name.color="green";
        name.cost=12000;
        System.out.println("Model :"+name.model);
        System.out.println("year  :"+name.year);
        System.out.println("color :"+name.color);
        System.out.println("cost  :"+name.cost);

        System.out.println();
        System.out.println("threest model");

        Telephone name3=new Telephone();
        name.model="samsung";
        name.year=2023;
        name.color="black";
        name.cost=80000;
        System.out.println("Model :"+name.model);
        System.out.println("year  :"+name.year);
        System.out.println("color :"+name.color);
        System.out.println("cost  :"+name.cost);

      */
//programmer
/*Scanner scanner=new Scanner(System.in);
Programmer programmer=new Programmer();
programmer.name=scanner.nextLine();
programmer.surName=scanner.nextLine();
programmer.age=scanner.nextInt();
int year = programmer.getyear();
        System.out.println(" name: "+programmer.name);
        System.out.println(" sur name: "+programmer.surName);
        System.out.println(" age: "+programmer.age);
        System.out.println(" programmer age is: "+programmer.age);
        System.out.println(year);

 */


Triangle d=new Triangle();
double vyvod;
Scanner scan = new Scanner(System.in);
        System.out.println(" Введите длину триугольника:");
d.a= scan.nextDouble();
        System.out.println(" Введите высоту:");
d.b=scan.nextDouble();
 vyvod=d.arra();
        System.out.println(" Площадь прямоугольника:"+vyvod);


        }
    }







