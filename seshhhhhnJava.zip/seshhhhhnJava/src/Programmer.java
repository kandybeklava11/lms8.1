public class Programmer {
    String name;
    String surName;
    int age;
    public int getyear(){
        return 2023-age;
    }


}
