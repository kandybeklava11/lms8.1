public class Telephone {
    String model;
    int year;
    String color;
    int cost;

}
