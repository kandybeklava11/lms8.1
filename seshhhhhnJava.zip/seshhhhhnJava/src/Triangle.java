public class Triangle {
    double a;
    double b;
    double c=2;





    public double arra() {
        double sss = (a * b)/c ;

        return sss;
    }
}
