public class sasa {
    String model;
    int price;
    int ram;
    String color;

    public void turnOn(){
        System.out.println("turn on");
    }
    public void turnOff(){
        System.out.println("turn off");

    }
}